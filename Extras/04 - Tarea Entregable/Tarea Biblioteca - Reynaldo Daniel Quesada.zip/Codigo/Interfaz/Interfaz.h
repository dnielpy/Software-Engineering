#include <Logica/Datos.h>

int ingresarLibro(struct libro libros[], int cantiLibros);
int eliminarLibros(struct libro libros[], int cantLibros);
void mostrarLibrosRegistrados(struct libro libros[], int cantLibros);
void mostrarReporte(struct libro libros[], int cantLibros);
