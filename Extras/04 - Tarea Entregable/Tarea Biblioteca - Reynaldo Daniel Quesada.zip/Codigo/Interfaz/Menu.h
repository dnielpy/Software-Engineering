#include <Logica/Datos.h>
#include <stdio.h>
#include <Logica/Logica.h>

void menu(struct libro libros[], int cantidadLibros);
