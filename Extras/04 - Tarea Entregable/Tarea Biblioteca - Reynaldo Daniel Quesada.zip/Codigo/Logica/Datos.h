#ifndef DATOS_H
#define DATOS_H

struct libro {
  char nombre[100];
  int cantPag;
};

typedef struct datosVolantes DatosVolantes;

#endif // DATOS_H
