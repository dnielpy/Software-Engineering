#include "Logica/Datos.h"
#include <stdbool.h>

void menu(DatosVolantes volantes[], float sales[5][4], char productos[5][10], char vendedores[4][15], bool productosVendidosTodosLosDias[5][4]);
void menuReportes(DatosVolantes volantes[4], bool productosVendidosTodosLosDias[5][4], char vendedores[][15], char productos[][10], float sales[][4]);
