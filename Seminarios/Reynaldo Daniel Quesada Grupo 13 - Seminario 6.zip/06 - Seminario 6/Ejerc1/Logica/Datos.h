#ifndef DATOS_H
#define DATOS_H

struct datosVolantes {
  int cantDias;
  float ventas[5][30];
};

typedef struct datosVolantes DatosVolantes;

#endif // DATOS_H
