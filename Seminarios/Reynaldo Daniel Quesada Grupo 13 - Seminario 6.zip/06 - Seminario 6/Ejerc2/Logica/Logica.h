#ifndef LOGICA_H
#define LOGICA_H
    void obtener(char valores[], char origen[], char resultado[], int indiceDeorigen);
#endif
