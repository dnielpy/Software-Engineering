#include <stdbool.h>

int pedirCantTriangulos();
float pedirLado(int lado);
float pedirAngulo();
bool clasificar(float area);
void resumen(float porcentaje, int grandes);
