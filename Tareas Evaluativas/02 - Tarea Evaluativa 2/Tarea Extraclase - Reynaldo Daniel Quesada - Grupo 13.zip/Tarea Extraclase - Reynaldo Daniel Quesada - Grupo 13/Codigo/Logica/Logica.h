float calcularArea(float a, float b, float angulo);
float calcularPorcentaje(int grandes, int total);
